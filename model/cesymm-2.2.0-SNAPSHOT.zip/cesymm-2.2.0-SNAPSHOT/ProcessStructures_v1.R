r <- read.fwf("~/Desktop/Sequencing/Assembly/TandemRepeats/cesymm-2.2.0-SNAPSHOT/cullpdb_pc50.0_res0.0-2.0_noBrks_len40-10000_R0.25_Xray_d2021_10_29_chains14689.txt", c(8, 6, 8, 8, 7, 100), skip=1)
r[[1]] <- gsub(" ", "", r[[1]], fixed=TRUE) # trim white space

pdb <- substring(r[[1]], 1, 4)
chain <- substring(r[[1]], 5) 

res <- setNames(vector("list", nrow(r)), r[[1]])
for (i in seq_along(res)) {
	print(i)
	t <- try(
			res[[i]] <- system(paste0("/Users/sixfoot10/Desktop/Sequencing/Assembly/TandemRepeats/cesymm-2.2.0-SNAPSHOT/runCESymm.sh -J --threads=6 --fasta=/Users/sixfoot10/Desktop/Sequencing/Assembly/TandemRepeats/cesymm-2.2.0-SNAPSHOT/alignments/",
				names(res)[i],
				".txt --stats=- ",
				pdb[i], ".", chain[i]),
			intern=TRUE,
			ignore.stderr=TRUE)[-1:-2],
		silent=TRUE)
	if (is(t, "try-error")) {
		print("error")
	} else {
		temp <- readLines(paste0("/Users/sixfoot10/Desktop/Sequencing/Assembly/TandemRepeats/cesymm-2.2.0-SNAPSHOT/alignments/",
			names(res)[i],
			".txt"))
		if (length(temp) > 1) {
			writeLines(temp[-length(temp)],
				paste0("/Users/sixfoot10/Desktop/Sequencing/Assembly/TandemRepeats/cesymm-2.2.0-SNAPSHOT/alignments/",
				names(res)[i],
				".fas"))
		}
		unlink(paste0("/Users/sixfoot10/Desktop/Sequencing/Assembly/TandemRepeats/cesymm-2.2.0-SNAPSHOT/alignments/",
			names(res)[i],
			".txt"))
	}
}
save(res, file="~/Desktop/Sequencing/Assembly/TandemRepeats/cesymm-2.2.0-SNAPSHOT/ResultPDBs_v1.RData", compress="xz")

### Threshold results on refined score threshold

load('~/Desktop/Sequencing/Assembly/TandemRepeats/cesymm-2.2.0-SNAPSHOT/ResultPDBs_v1.RData')

res <- unlist(res)
res <- strsplit(res, "\t")
w <- which(lengths(res) == 16) # missing repeats
res[w] <- lapply(res[w], c, NA_character_)
res <- do.call(cbind, res)
res <- t(res)
res <- as.data.frame(res)
res <- res[res[, "V11"] >= 0.7,]

### Inspect the repeat alignments

library(DECIPHER)
path <- "~/Desktop/Sequencing/Assembly/TandemRepeats/cesymm-2.2.0-SNAPSHOT/alignments/"
ls <- list.files(path, pattern="\\.fas")
d <- setNames(vector("list", length(ls)),
	substring(ls, 1, nchar(ls) - 4))
for (i in seq_along(ls)) {
	print(i)
	aa <- readBStringSet(paste0(path, ls[i]))
	names(aa) <- seq_along(aa)
	aa <- AAStringSet(toupper(aa))
	#BrowseSeqs(aa)
	d[[i]] <- DistanceMatrix(aa, verbose=FALSE, type="dist", penalizeGapLetter=FALSE)
#	if (length(aa) < 3)
#		next
#	c <- IdClusters(d[[i]], method="NJ", show=FALSE, verbose=FALSE, type="dendrogram")
#	c <- reorder(c, seq_along(aa))
#	p <- cor.test(unlist(c), seq_along(aa), method="spearman")$p.value
#	if (p < 0.05) {
#		dev.new()
#		plot(c)
#	}
}

dists <- sapply(d, min)
hist(dists)

plot(sort(dists[dists > 0]), log="x")
#abline(a=-0.05, b=0.38)

plot(dists[rownames(res)], res$V11)

### Make benchmark

AA <- readAAStringSet("~/Desktop/Sequencing/Assembly/TandemRepeats/cesymm-2.2.0-SNAPSHOT/cullpdb_pc50.0_res0.0-2.0_noBrks_len40-10000_R0.25_Xray_d2021_10_29_chains14689.fasta.txt")
names(AA) <- gsub("^([A-Z0-9]+) .*", "\\1", names(AA))
AA <- AA[rownames(res)]
start <- gsub("^.{6,8}_(-?[0-9]+)-.*$", "\\1", res$V17)
end <- gsub(".*-([0-9]+)$", "\\1", res$V17)
start <- as.numeric(start)
end <- as.numeric(end)
start <- ifelse(start < 1, 1, start)
end <- ifelse(end > width(AA), width(AA), end)

### Make decoy (shuffled) set

K <- 4
pBar <- txtProgressBar(style=3)
DECOY <- AA
for (i in seq_along(DECOY)) {
	starts <- seq(1, width(DECOY[i]) - K + 1, by=K)
	s <- extractAt(DECOY[[i]],
		IRanges(starts,
			width=K))
	s <- unlist(sample(s))
	DECOY[[i]] <- xscat(s,
		subseq(DECOY[[i]], starts[length(starts)] + K, width(DECOY[i])))
	setTxtProgressBar(pBar, i/length(DECOY))
}
