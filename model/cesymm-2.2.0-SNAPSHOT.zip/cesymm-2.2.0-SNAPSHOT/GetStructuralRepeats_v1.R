#https://github.com/rcsb/symmetry/blob/master/symmetry-tools/docs/CeSymm.md

